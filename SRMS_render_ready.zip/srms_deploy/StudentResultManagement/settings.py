import os
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

LOGIN_URL = '/login/'

SECRET_KEY = os.environ.get('SECRET_KEY')

DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'

ALLOWED_HOSTS = [host.strip() for host in os.environ.get('ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',') if host.strip()]

# Render sets this automatically to <your-service>.onrender.com
RENDER_EXTERNAL_HOSTNAME = os.environ.get('RENDER_EXTERNAL_HOSTNAME')
if RENDER_EXTERNAL_HOSTNAME:
    ALLOWED_HOSTS.append(RENDER_EXTERNAL_HOSTNAME)

CSRF_TRUSTED_ORIGINS = [o.strip() for o in os.environ.get('CSRF_TRUSTED_ORIGINS', '').split(',') if o.strip()]
if RENDER_EXTERNAL_HOSTNAME:
    CSRF_TRUSTED_ORIGINS.append(f'https://{RENDER_EXTERNAL_HOSTNAME}')

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'resultapp',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'StudentResultManagement.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'resultapp', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'StudentResultManagement.wsgi.application'

import dj_database_url

# If DATABASE_URL is set (e.g. Render Postgres), use it. Otherwise fall back
# to local SQLite. NOTE: Render's free web services have an ephemeral
# filesystem, so SQLite data will NOT persist across deploys/restarts there —
# attach a Render Postgres database (set DATABASE_URL) for real persistence.
DATABASES = {
    'default': dj_database_url.config(
        default=f"sqlite:///{BASE_DIR / os.environ.get('DB_NAME', 'db.sqlite3')}",
        conn_max_age=600,
    )
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Kolkata'

USE_I18N = True

USE_TZ = True

STATIC_URL = '/static/'
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'resultapp', 'static')]
STATIC_ROOT = BASE_DIR / 'staticfiles'

STORAGES = {
    "default": {
        "BACKEND": "django.core.files.storage.FileSystemStorage",
    },
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage",
    },
}

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Email settings
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', 'shubhamds21125@gmail.com')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD')
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'shubhamds21125@gmail.com')

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# ── Session settings ──────────────────────────────────────────────────────────
# Use database-backed sessions (default) and force save on every request.
# This is critical for Google OAuth — the state token written in admin_google_login
# must be persisted before Django redirects to Google's consent screen.
SESSION_ENGINE = 'django.contrib.sessions.backends.db'
SESSION_SAVE_EVERY_REQUEST = True
SESSION_COOKIE_AGE = 86400          # 24 hours
SESSION_COOKIE_SAMESITE = 'Lax'     # Lax allows the OAuth redirect callback to carry the cookie
SESSION_COOKIE_SECURE = bool(RENDER_EXTERNAL_HOSTNAME)  # True on Render (https), False for local dev

# ── Google OAuth2 ─────────────────────────────────────────────────────────────
# Credentials are loaded from .env (via python-dotenv's load_dotenv() above).
# The .env file must have:
#   GOOGLE_OAUTH2_CLIENT_ID     = <your-client-id>.apps.googleusercontent.com
#   GOOGLE_OAUTH2_CLIENT_SECRET = GOCSPX-...
#   GOOGLE_OAUTH2_REDIRECT_URI  = http://localhost:8080/admin-google-callback/
#
# In Google Cloud Console → Credentials → your OAuth client:
#   • Authorised redirect URIs must include the REDIRECT_URI above exactly.
GOOGLE_OAUTH2_CLIENT_ID     = os.environ.get('GOOGLE_OAUTH2_CLIENT_ID', '')
GOOGLE_OAUTH2_CLIENT_SECRET = os.environ.get('GOOGLE_OAUTH2_CLIENT_SECRET', '')
GOOGLE_OAUTH2_REDIRECT_URI  = os.environ.get('GOOGLE_OAUTH2_REDIRECT_URI',
                                              'http://localhost:8080/admin-google-callback/')

# Comma-separated list of Google account emails allowed to log in as admin.
# Leave empty ('') to allow any Google account that already has a superuser
# Django account with the same email.
GOOGLE_ADMIN_ALLOWED_EMAILS = os.environ.get('GOOGLE_ADMIN_ALLOWED_EMAILS', '')


# ── Gemini AI (Free tier) ─────────────────────────────
# Get your FREE API key from: https://aistudio.google.com/app/apikey
# No credit card required. Paste your key below.
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')