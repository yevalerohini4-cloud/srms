import os

target_dir = r"resultapp/templates"
old_pattern = """  gsap.fromTo('tbody tr',
    { opacity: 0, x: -14 },
    { opacity: 1, x: 0, duration: 0.4, stagger: 0.04, ease: 'power2.out', delay: 0.5 }
  );"""

new_pattern = """  gsap.fromTo('tbody tr',
    { opacity: 0, x: -10 },
    { opacity: 1, x: 0, duration: 0.15, stagger: 0.008, ease: 'power2.out', delay: 0.08 }
  );"""

count = 0
for root, dirs, files in os.walk(target_dir):
    for file in files:
        if file.endswith('.html'):
            filepath = os.path.join(root, file)
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            if old_pattern in content:
                content = content.replace(old_pattern, new_pattern)
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Updated: {filepath}")
                count += 1

print(f"Total files updated: {count}")
