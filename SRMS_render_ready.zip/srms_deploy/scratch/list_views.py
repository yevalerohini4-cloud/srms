import ast

with open("../resultapp/views.py", "r", encoding="utf-8") as f:
    node = ast.parse(f.read())

for child in node.body:
    if isinstance(child, ast.FunctionDef):
        print(f"Function: {child.name} (line {child.lineno})")
