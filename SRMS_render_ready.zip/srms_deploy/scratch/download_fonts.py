import re
import os
import urllib.request

css_path = r"resultapp/static/vendor/fonts/google-fonts.css"
output_dir = r"resultapp/static/vendor/fonts/files"
output_css = r"resultapp/static/vendor/fonts/fonts.css"

os.makedirs(output_dir, exist_ok=True)

with open(css_path, 'r', encoding='utf-8') as f:
    content = f.read()

# We want to find all font-face blocks
# An @font-face block looks like:
# /* latin */
# @font-face {
#   font-family: 'JetBrains Mono';
#   font-style: normal;
#   font-weight: 400;
#   font-display: swap;
#   src: url(url) format('woff2');
#   unicode-range: ...
# }

# Let's split content by @font-face
# Each block can be matched with its comment before it

blocks = re.findall(r'(/\*\s*([a-z\-]+)\s*\*/\s*@font-face\s*\{[^}]+\})', content, re.MULTILINE)

fonts_to_download = []
generated_rules = []

for block_text, subset in blocks:
    if subset != 'latin':
        continue
    
    # Extract font-family, style, weight, src
    family_match = re.search(r"font-family:\s*'([^']+)'", block_text)
    style_match = re.search(r"font-style:\s*([a-z]+)", block_text)
    weight_match = re.search(r"font-weight:\s*(\d+)", block_text)
    src_match = re.search(r"src:\s*url\(([^)]+)\)\s*format\('woff2'\)", block_text)
    
    if not (family_match and style_match and weight_match and src_match):
        continue
        
    family = family_match.group(1)
    style = style_match.group(1)
    weight = weight_match.group(1)
    url = src_match.group(1)
    
    # Create clean file name
    clean_family = family.lower().replace(' ', '-')
    file_name = f"{clean_family}-latin-{weight}-{style}.woff2"
    
    fonts_to_download.append((url, file_name))
    
    # Create @font-face rule for the new fonts.css
    rule = f"""@font-face {{
  font-family: '{family}';
  font-style: {style};
  font-weight: {weight};
  font-display: swap;
  src: url('./files/{file_name}') format('woff2');
}}"""
    generated_rules.append(rule)

print(f"Found {len(fonts_to_download)} latin fonts to download.")

# Download each font
for url, name in fonts_to_download:
    dest_path = os.path.join(output_dir, name)
    print(f"Downloading {url} -> {dest_path}")
    try:
        urllib.request.urlretrieve(url, dest_path)
    except Exception as e:
        print(f"Failed to download {name}: {e}")

# Write fonts.css
with open(output_css, 'w', encoding='utf-8') as f:
    f.write("/* Self-hosted fonts — Playfair Display, Source Sans 3, and JetBrains Mono (latin subset) */\n\n")
    f.write("\n\n".join(generated_rules))
    f.write("\n")

print("Generated new fonts.css successfully.")
