# Deploy to Render — fast path

## Option A: One-click via render.yaml (Blueprint)
1. Push this project to a GitHub repo.
2. In Render: **New +** → **Blueprint** → connect the repo. Render reads
   `render.yaml` and creates the web service + a free Postgres database for you.
3. Fill in the `sync: false` env vars in the Render dashboard (email, Google
   OAuth, Gemini key) — leave any you don't use blank.
4. Click **Apply**. First deploy runs `build.sh` (installs deps, collects
   static, runs migrations) then starts Gunicorn.
5. Create a superuser once it's live: Render dashboard → your service →
   **Shell** → `python manage.py createsuperuser`.

## Option B: Manual web service
1. **New +** → **Web Service** → connect repo.
2. Build command: `./build.sh`
3. Start command: `gunicorn StudentResultManagement.wsgi:application`
4. Add env vars: `SECRET_KEY`, `DEBUG=False`, `ALLOWED_HOSTS=.onrender.com`
   (plus email/OAuth/Gemini vars as needed).
5. (Recommended) Add a Render Postgres instance and set `DATABASE_URL` to its
   connection string — see note below.

## Important: SQLite won't persist on Render's free tier
Free web services have an **ephemeral filesystem** — anything written to disk
(including `db.sqlite3` and uploaded photos in `media/`) is wiped on every
deploy or restart. This app now reads `DATABASE_URL` automatically
(`dj-database-url`), so:
- Attach a free Render Postgres database and set `DATABASE_URL` → your data
  survives restarts/redeploys.
- `media/` uploads still won't persist on the free plan (no attached disk).
  Either upgrade to a paid instance + add a Render disk mounted at `media/`,
  or switch to S3/Cloudinary for uploads.

## What changed in this repo for deployment
- `requirements.txt`: added `gunicorn`, `whitenoise`, `dj-database-url`, `psycopg2-binary`
- `settings.py`: WhiteNoise middleware + compressed static storage,
  `STATIC_ROOT`, `DATABASE_URL` support (falls back to SQLite locally),
  `ALLOWED_HOSTS`/`CSRF_TRUSTED_ORIGINS` auto-include the Render hostname,
  secure session cookies when running on Render.
- `urls.py`: media files are now served by Django even with `DEBUG=False`
  (fine for a small app; move to S3/Cloudinary if you outgrow it).
- `build.sh`: installs deps, runs `collectstatic`, runs `migrate`.
- `render.yaml`: Blueprint for one-click deploy (web service + free Postgres).

## Env vars you must set
`SECRET_KEY` (render.yaml auto-generates it), and whichever of these your
features need: `EMAIL_HOST_USER`, `EMAIL_HOST_PASSWORD`, `DEFAULT_FROM_EMAIL`,
`GOOGLE_OAUTH2_CLIENT_ID`, `GOOGLE_OAUTH2_CLIENT_SECRET`,
`GOOGLE_OAUTH2_REDIRECT_URI` (update to `https://<your-app>.onrender.com/admin-google-callback/`
and update the same URI in Google Cloud Console), `GOOGLE_ADMIN_ALLOWED_EMAILS`,
`GEMINI_API_KEY`.
