from django.test import TestCase, Client
from django.contrib.auth.models import User
from django.urls import reverse
from resultapp.models import Teacher, Class, Subject, Student, Result

class TeacherPortalTests(TestCase):
    def setUp(self):
        self.client = Client()
        # Create users
        self.teacher_user = User.objects.create_user(username='teacher1', password='password123')
        self.admin_user = User.objects.create_superuser(username='admin1', password='password123')
        
        # Create teacher profile
        self.teacher = Teacher.objects.create(user=self.teacher_user, department='CS')
        
        # Create Class and Subject
        self.cls = Class.objects.create(class_name='Class 10', class_numeric=10, section='A')
        self.subj = Subject.objects.create(subject_name='Math', subject_code='MATH101', credits=4)
        
        # Assign to teacher
        self.teacher.assigned_classes.add(self.cls)
        self.teacher.assigned_subjects.add(self.subj)

    def test_teacher_dashboard_requires_teacher_role(self):
        # Unauthenticated redirect to login
        response = self.client.get(reverse('teacher_dashboard'))
        self.assertEqual(response.status_code, 302)

        # Authenticate as admin user (not teacher)
        self.client.login(username='admin1', password='password123')
        response = self.client.get(reverse('teacher_dashboard'))
        self.assertEqual(response.status_code, 302) # Redirects to login with warning

        # Authenticate as teacher
        self.client.login(username='teacher1', password='password123')
        response = self.client.get(reverse('teacher_dashboard'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Class 10')
        self.assertContains(response, 'Math')

    def test_export_students_csv(self):
        # Admin login
        self.client.login(username='admin1', password='password123')
        
        # Create dummy student
        Student.objects.create(roll_id='S1001', name='John Doe', email='john@example.com', student_class=self.cls, status=True)
        
        response = self.client.get(reverse('export_students_csv'))
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response['Content-Disposition'], 'attachment; filename="srms_students.csv"')
        
        # Verify content matches
        content = response.getvalue().decode('utf-8')
        self.assertIn('John Doe', content)
        self.assertIn('S1001', content)


from resultapp.views.students import compute_attendance_stats
from resultapp.models import Attendance

class AttendanceStatsTests(TestCase):
    def setUp(self):
        self.cls = Class.objects.create(class_name='Class 10', class_numeric=10, section='A')
        self.student = Student.objects.create(
            roll_id='S9999', name='Jane Doe', email='jane@example.com',
            student_class=self.cls, dob='2005-01-01', status=1
        )
        self.subj1 = Subject.objects.create(subject_name='Math', subject_code='M101')
        self.subj2 = Subject.objects.create(subject_name='Science', subject_code='S102')
        self.subj3 = Subject.objects.create(subject_name='English', subject_code='E103')

    def test_multiple_subjects_same_day_counts_as_one_day(self):
        # 1 student + 3 subjects marked on the same day
        from datetime import date
        d = date(2026, 8, 1)
        Attendance.objects.create(student=self.student, date=d, subject=self.subj1, status='present')
        Attendance.objects.create(student=self.student, date=d, subject=self.subj2, status='present')
        Attendance.objects.create(student=self.student, date=d, subject=self.subj3, status='absent')
        
        stats = compute_attendance_stats(self.student)
        # Since 'present' is in the set, the unique date status is present, which counts as 1 day attended and 1 day total.
        self.assertEqual(stats['total_days'], 1)
        self.assertEqual(stats['present_days'], 1)
        self.assertEqual(stats['absent_days'], 0)
        self.assertEqual(stats['percentage'], 100.0)

    def test_attendance_status_weighting(self):
        from datetime import date
        # Day 1: Late -> counts as attended (1/1)
        Attendance.objects.create(student=self.student, date=date(2026, 8, 1), subject=self.subj1, status='late')
        
        # Day 2: Excused -> ignored from calculation (0/0)
        Attendance.objects.create(student=self.student, date=date(2026, 8, 2), subject=self.subj1, status='excused')
        
        # Day 3: Absent -> counts as absent (0/1)
        Attendance.objects.create(student=self.student, date=date(2026, 8, 3), subject=self.subj1, status='absent')
        
        stats = compute_attendance_stats(self.student)
        # Total days (denominator) should be 2, Present + Late should be 1 (since Day 1 is late), Absent is 1, Excused is 1
        self.assertEqual(stats['total_days'], 2)
        self.assertEqual(stats['late_days'], 1)
        self.assertEqual(stats['absent_days'], 1)
        self.assertEqual(stats['excused_days'], 1)
        self.assertEqual(stats['percentage'], 50.0)

