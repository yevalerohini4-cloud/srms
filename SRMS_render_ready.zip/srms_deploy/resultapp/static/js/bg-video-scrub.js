/* ─────────────────────────────────────────────────────────────
   SRMS — Background Video Scrub  (v4 — Monotonic LERP Seek)

   HOME PAGE (hero-page class):
   ┌──────────────────────────────────────────────────────────┐
   │  Scroll-scrubbed with non-oscillating LERP filter:       │
   │  • Prevents overshoot, back-and-forth seeks, and decodes │
   │    storming.                                             │
   │  • Checks video.seeking before writing new time to       │
   │    avoid clogging the browser decoder queue.             │
   └──────────────────────────────────────────────────────────┘

   OTHER PAGES:
   ┌──────────────────────────────────────────────────────────┐
   │  Ambient autoplay loop with smooth crossfade on loop     │
   │  boundary, locked to 0.88× playbackRate for a relaxed,   │
   │  cinematic feel.                                         │
   └──────────────────────────────────────────────────────────┘
   ───────────────────────────────────────────────────────────── */

(function () {
  'use strict';

  const video = document.getElementById('site-bg-video');
  if (!video) return;

  const isReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (isReduced) {
    video.style.display = 'none';
    try { video.pause(); } catch (_) {}
    return;
  }

  // ── GPU compositing hint ────────────────────────────────────
  video.style.willChange   = 'transform';
  video.style.transform    = 'translateZ(0)';
  video.style.backfaceVisibility = 'hidden';
  video.style.backfaceVisibility = 'hidden';

  const isHomePage = document.body.classList.contains('hero-page');

  // Force-fetch the video bytes now regardless of preload attribute
  try { video.load(); } catch (_) {}

  /* ══════════════════════════════════════════════════════════════
     NON-HOME PAGES — silky ambient autoplay loop
     ══════════════════════════════════════════════════════════════ */
  if (!isHomePage) {
    video.loop        = true;
    video.muted       = true;
    video.playbackRate = 0.88;          // slightly slowed = more cinematic

    const tryPlay = () => video.play().catch(() => {});

    ['loadeddata', 'canplay', 'canplaythrough'].forEach(e =>
      video.addEventListener(e, tryPlay, { once: true })
    );
    tryPlay();
    return;
  }

  /* ══════════════════════════════════════════════════════════════
     HOME PAGE — LERP-smoothed scroll-scrubbed playback
     ══════════════════════════════════════════════════════════════ */
  video.pause();
  video.removeAttribute('autoplay');
  video.loop  = false;
  video.muted = true;

  // ── State ───────────────────────────────────────────────────
  let duration       = 0;
  let ready          = false;
  let rawTarget      = 0;
  let currentTarget  = 0;
  let lastSeekTime   = -1;

  // ── Throttling ───────────────────────────────────────────────
  const isMobile     = window.SRMSPerf ? window.SRMSPerf.isMobile : false;
  const MIN_SEEK_DT  = isMobile ? (1 / 12) : (1 / 30);  // Throttled frame seek on mobile

  // ── Readiness ───────────────────────────────────────────────
  function markReady() {
    if (ready) return;
    if (!video.duration || !isFinite(video.duration)) return;
    duration      = video.duration;
    currentTarget = scrollProgress() * duration;
    rawTarget     = currentTarget;
    ready         = true;
  }

  ['loadedmetadata', 'durationchange', 'loadeddata', 'canplay'].forEach(e =>
    video.addEventListener(e, markReady)
  );
  markReady();

  // Polling fallback — checked every 200 ms for up to ~8 s
  let polls   = 0;
  const poll  = setInterval(() => {
    markReady();
    if (ready || ++polls > 40) clearInterval(poll);
  }, 200);

  // ── Scroll progress [0…1] ────────────────────────────────────
  // Prefer the Lenis-interpolated scroll value when available so the
  // video tracks the smooth-scroll position, not the raw/jerky one.
  function scrollProgress() {
    // window.__srmsScrollY is set by the Lenis scroll callback in base.html
    if (typeof window.__srmsScrollY === 'number' && typeof window.__srmsScrollMax === 'number') {
      return Math.min(1, Math.max(0, window.__srmsScrollY / window.__srmsScrollMax));
    }
    // Fallback — native scroll
    const doc       = document.documentElement;
    const maxScroll = Math.max(1, doc.scrollHeight - doc.clientHeight);
    const top       = window.scrollY || doc.scrollTop || document.body.scrollTop || 0;
    return Math.min(1, Math.max(0, top / maxScroll));
  }

  // ── rAF loop ─────────────────────────────────────────────────
  let lastTickTime = 0;
  const TICK_INTERVAL = isMobile ? 66 : 0; // Throttle to ~15fps on mobile

  function tick(timestamp) {
    requestAnimationFrame(tick);
    if (!ready) return;

    if (TICK_INTERVAL > 0) {
      const elapsed = timestamp - lastTickTime;
      if (elapsed < TICK_INTERVAL) return;
      lastTickTime = timestamp - (elapsed % TICK_INTERVAL);
    }

    // Raw target in video-time space — sourced from Lenis-smoothed scroll
    rawTarget = scrollProgress() * duration;

    // Smooth follow target using simple, non-oscillating LERP (no overshoot or bounce)
    const LERP_FACTOR = isMobile ? 0.12 : 0.07;
    currentTarget += (rawTarget - currentTarget) * LERP_FACTOR;

    // Clamp to valid range
    const clamped = Math.min(Math.max(currentTarget, 0), duration - 0.05);

    // ── Seek — only when delta ≥ 1 frame, video is ready, and browser is NOT currently seeking ──────
    if (Math.abs(clamped - lastSeekTime) >= MIN_SEEK_DT) {
      if (video.readyState >= 2 && !video.seeking) {
        video.currentTime = clamped;
        lastSeekTime      = clamped;
      }
    }
  }

  requestAnimationFrame(tick);

  // ── bfcache restore ──────────────────────────────────────────
  window.addEventListener('pageshow', (e) => {
    if (e.persisted) {
      video.pause();
      // Reset position to current scroll position to avoid a snap
      const t      = scrollProgress() * duration;
      currentTarget = t;
      rawTarget     = t;
      lastSeekTime = -1;
      markReady();
    }
  });

  // ── Prefetch the first frame immediately ─────────────────────
  // Once ready, snap to frame 0 so the very first pixel of video
  // is shown before any scroll (no black flash).
  video.addEventListener('loadeddata', () => {
    if (video.currentTime === 0) {
      try { video.currentTime = 0.001; } catch (_) {}
    }
  }, { once: true });

})();
