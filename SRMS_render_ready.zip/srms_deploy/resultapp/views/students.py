import logging
from datetime import datetime, timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Avg, Q
from django.db import IntegrityError
from django.http import JsonResponse
from django.core.mail import send_mail
from django.urls import reverse

from resultapp.models import (
    Student, Class, Subject, Result, SubjectCombination, BranchSubject,
    Parent, Attendance, ProgressReport, Notice, Branch
)

logger = logging.getLogger(__name__)


def paginate(request, object_list, per_page=10):
    from django.core.paginator import Paginator
    paginator = Paginator(object_list, per_page)
    page_number = request.GET.get('page')
    return paginator.get_page(page_number)


def get_grade(percentage, is_failed):
    """Mumbai University NEP 2020 — UGC 10-point grading scale"""
    if is_failed:
        return 'F'
    if percentage >= 80:  return 'O'
    if percentage >= 70:  return 'A+'
    if percentage >= 60:  return 'A'
    if percentage >= 55:  return 'B+'
    if percentage >= 50:  return 'B'
    if percentage >= 45:  return 'C'
    if percentage >= 40:  return 'D'
    return 'F'


def get_grade_point(grade):
    return {'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'D': 4, 'F': 0}.get(grade, 0)


def get_sgpa(results):
    """
    NEP 2020 credit-weighted SGPA/CGPA formula (used for BSc CS and other
    NEP-aligned branches):
        SGPA = Σ(credit × grade_point) / Σ(credit)
    Falls back to a simple average if a result's subject has no credit
    value set (defensive — Subject.credits defaults to 4).
    """
    results = list(results)
    if not results:
        return 0
    total_credits = sum((r.subject.credits if r.subject else 4) or 4 for r in results)
    if total_credits == 0:
        return 0
    weighted_points = sum(
        r.nep_grade_point * ((r.subject.credits if r.subject else 4) or 4) for r in results
    )
    return round(weighted_points / total_credits, 2)


def compute_attendance_stats(student, date_from=None, date_to=None, month=None, year=None):
    """
    Computes attendance statistics for a single student by grouping records by date.
    
    Priority Rule for Day-level Status Calculation:
    - If 'present' is in the statuses for a day, the day counts as present.
    - Else if 'late' is in the statuses for a day, the day counts as late.
    - Else if 'absent' is in the statuses for a day, the day counts as absent.
    - Otherwise (all are 'excused'), the day counts as excused.
    
    Status weight rules:
    - Present/Late: counts as attended (1 day present / 1 day total).
    - Absent: counts against the student (0 days present / 1 day total).
    - Excused: ignored entirely (0 days present / 0 days total).
    """
    from collections import defaultdict
    qs = Attendance.objects.filter(student=student)
    if date_from:
        qs = qs.filter(date__gte=date_from)
    if date_to:
        qs = qs.filter(date__lte=date_to)
    if month:
        qs = qs.filter(date__month=month)
    if year:
        qs = qs.filter(date__year=year)

    date_statuses = defaultdict(set)
    for record in qs:
        date_statuses[record.date].add(record.status)

    total_days = 0
    present_days = 0
    late_days = 0
    absent_days = 0
    excused_days = 0

    for date, statuses in date_statuses.items():
        if 'present' in statuses:
            present_days += 1
            total_days += 1
        elif 'late' in statuses:
            late_days += 1
            total_days += 1
        elif 'absent' in statuses:
            absent_days += 1
            total_days += 1
        elif 'excused' in statuses:
            excused_days += 1

    percentage = round((present_days + late_days) / total_days * 100, 2) if total_days > 0 else 0.0

    return {
        'total_days': total_days,
        'present_days': present_days,
        'late_days': late_days,
        'absent_days': absent_days,
        'excused_days': excused_days,
        'attended_days': present_days + late_days,
        'percentage': percentage,
    }



@login_required
def add_student(request):
    classes = Class.objects.all()
    if request.method == 'POST':
        try:
            student_class = get_object_or_404(Class, id=request.POST.get('class'))
            photo_file = request.FILES.get('photo')
            Student.objects.create(
                name=request.POST.get('fullname'),
                roll_id=request.POST.get('rollid'),
                email=request.POST.get('emailid'),
                gender=request.POST.get('gender'),
                dob=request.POST.get('dob') or None,
                student_class=student_class,
                photo=photo_file,
                phone=request.POST.get('phone', '').strip() or None,
                address=request.POST.get('address', '').strip() or None,
                emergency_contact_name=request.POST.get('emergency_contact_name', '').strip() or None,
                emergency_contact_phone=request.POST.get('emergency_contact_phone', '').strip() or None,
                blood_group=request.POST.get('blood_group', '').strip() or None,
            )
            messages.success(request, "Student info added successfully!")
        except IntegrityError:
            messages.error(request, "A student with that roll number or email already exists.")
        except Exception:
            logger.exception("Failed to add student")
            messages.error(request, "Couldn't add the student. An unexpected error occurred.")
        return redirect('add_student')
    return render(request, 'add_student.html', {'classes': classes})


@login_required
def manage_students(request):
    if request.method == 'POST':
        if request.POST.get('delete'):
            try:
                student_obj = get_object_or_404(Student, id=request.POST.get('delete'))
                student_obj.delete()
                messages.success(request, "Student deleted successfully!")
            except Exception:
                logger.exception("Failed to delete student")
                messages.error(request, "Couldn't delete the student. An unexpected error occurred.")
            return redirect('manage_students')
            
        elif request.POST.get('deactivate'):
            try:
                student_obj = get_object_or_404(Student, id=request.POST.get('deactivate'))
                student_obj.status = 0
                student_obj.save()
                messages.success(request, f"Student '{student_obj.name}' deactivated successfully!")
            except Exception:
                logger.exception("Failed to deactivate student")
                messages.error(request, "Couldn't deactivate the student. An unexpected error occurred.")
            return redirect('manage_students')
            
        elif request.POST.get('activate'):
            try:
                student_obj = get_object_or_404(Student, id=request.POST.get('activate'))
                student_obj.status = 1
                student_obj.save()
                messages.success(request, f"Student '{student_obj.name}' activated successfully!")
            except Exception:
                logger.exception("Failed to activate student")
                messages.error(request, "Couldn't activate the student. An unexpected error occurred.")
            return redirect('manage_students')

    # Query params
    status_filter = request.GET.get('status', 'active')
    selected_branch_id = request.GET.get('branch', '')
    attendance_filter = request.GET.get('attendance_filter', '')
    q = request.GET.get('q', '').strip()

    students = Student.objects.select_related('student_class', 'student_class__branch').all().order_by('name')

    if status_filter == 'active':
        students = students.filter(status=1)
    elif status_filter == 'inactive':
        students = students.filter(status=0)

    if selected_branch_id:
        students = students.filter(student_class__branch_id=selected_branch_id)

    if q:
        students = students.filter(
            Q(name__icontains=q) | Q(roll_id__icontains=q) | Q(email__icontains=q) |
            Q(student_class__class_name__icontains=q) | Q(student_class__section__icontains=q)
        )

    students_list = list(students)
    thirty_days_ago = datetime.now().date() - timedelta(days=30)
    for s in students_list:
        s.attendance_stats_30d = compute_attendance_stats(s, date_from=thirty_days_ago)

    # Filter by attendance in python
    if attendance_filter:
        filtered_list = []
        for s in students_list:
            pct = s.attendance_stats_30d['percentage']
            if attendance_filter == 'at_risk':
                if pct < 75.0:
                    filtered_list.append(s)
            elif attendance_filter == 'excellent':
                if pct >= 90.0 and s.attendance_stats_30d['total_days'] > 0:
                    filtered_list.append(s)
        students_list = filtered_list

    branches = Branch.objects.filter(status=1)
    page_obj = paginate(request, students_list)
    
    return render(request, 'manage_students.html', {
        'students': page_obj,
        'page_obj': page_obj,
        'q': q,
        'status_filter': status_filter,
        'selected_branch_id': selected_branch_id,
        'attendance_filter': attendance_filter,
        'branches': branches,
    })


@login_required
def edit_student(request, student_id):
    student_obj = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        try:
            if request.FILES.get('photo'):
                student_obj.photo = request.FILES.get('photo')
            student_obj.name = request.POST.get('fullname')
            student_obj.roll_id = request.POST.get('rollid')
            student_obj.email = request.POST.get('emailid')
            student_obj.gender = request.POST.get('gender')
            student_obj.dob = request.POST.get('dob') or None
            student_obj.status = int(request.POST.get('status'))
            student_obj.phone = request.POST.get('phone', '').strip() or None
            student_obj.address = request.POST.get('address', '').strip() or None
            student_obj.emergency_contact_name = request.POST.get('emergency_contact_name', '').strip() or None
            student_obj.emergency_contact_phone = request.POST.get('emergency_contact_phone', '').strip() or None
            student_obj.blood_group = request.POST.get('blood_group', '').strip() or None
            student_obj.save()
            messages.success(request, "Student updated successfully!")
        except IntegrityError:
            messages.error(request, "Another student already uses that roll number or email.")
        except Exception:
            logger.exception("Failed to edit student %s", student_id)
            messages.error(request, "Couldn't update the student. An unexpected error occurred.")
        return redirect('manage_students')
    return render(request, 'edit_student.html', {'student_obj': student_obj})


@login_required
def add_result(request):
    classes = Class.objects.all()
    if request.method == 'POST':
        try:
            class_id = request.POST.get('class')
            student_id = request.POST.get('studentid')
            semester_id = request.POST.get('semester') or 1
            subject_ids = set()
            for key in request.POST:
                for prefix in ('theory_', 'internal_', 'practical_', 'oral_'):
                    if key.startswith(prefix):
                        subject_ids.add(key.split('_', 1)[1])

            for subject_id in subject_ids:
                theory_val   = request.POST.get(f'theory_{subject_id}')
                internal_val = request.POST.get(f'internal_{subject_id}')
                practical_val= request.POST.get(f'practical_{subject_id}') or None
                oral_val     = request.POST.get(f'oral_{subject_id}') or None

                Result.objects.create(
                    student_id=student_id,
                    student_class_id=class_id,
                    subject_id=subject_id,
                    semester=int(semester_id),
                    theory_marks=int(theory_val or 0),
                    internal_marks=int(internal_val or 0),
                    practical_marks=int(practical_val) if practical_val else None,
                    oral_marks=int(oral_val) if oral_val else None,
                )

            student = get_object_or_404(Student, id=student_id)
        except ValueError:
            messages.error(request, "Marks must be whole numbers — please check each field and try again.")
            return redirect('add_result')
        except Exception:
            logger.exception("Failed to save result")
            messages.error(request, "Couldn't save the result. An unexpected error occurred.")
            return redirect('add_result')

        try:
            if student.email:
                send_mail(
                    subject='Your Result Has Been Added - SRMS',
                    message=(
                        f'Dear {student.name},\n\nYour result has been added successfully by the school.\n\n'
                        'Please visit the school portal to check your full result.\n\n'
                        f'Roll ID: {student.roll_id}\nClass: {student.student_class}\n\nRegards,\nSRMS College'
                    ),
                    from_email=None,
                    recipient_list=[student.email],
                    fail_silently=True,
                )

            for parent in Parent.objects.filter(student=student).select_related('user'):
                if parent.user.email:
                    send_mail(
                        subject=f'Result Added for {student.name} - SRMS',
                        message=(
                            f'Dear {parent.user.get_full_name()},\n\n'
                            f'The result for your child {student.name} has been added.\n\n'
                            'Please login to the parent portal to view the full result.\n\nRegards,\nSRMS College'
                        ),
                        from_email=None,
                        recipient_list=[parent.user.email],
                        fail_silently=True,
                    )

            messages.success(request, "Result info added successfully!")
        except Exception:
            logger.exception("Notice added but emails failed to send")
            messages.success(request, "Result info added successfully!")
            messages.warning(request, "Note: the student/parent notification email may not have been sent.")
        return redirect('add_result')
    return render(request, 'add_result.html', {'classes': classes})


def get_students_subjects(request):
    class_id = request.GET.get('class_id')
    semester  = request.GET.get('semester')

    if class_id:
        students = list(Student.objects.filter(student_class_id=class_id, status=1).values('id', 'name', 'roll_id'))

        sc_qs = SubjectCombination.objects.filter(
            student_class_id=class_id, status=1
        ).select_related('subject')
        subjects_from_sc = [
            {'id': sc.subject.id, 'subject_name': sc.subject.subject_name, 'subject_code': sc.subject.subject_code}
            for sc in sc_qs
        ]

        try:
            class_obj = Class.objects.select_related('branch').get(id=class_id)
            if class_obj.branch:
                bs_qs = BranchSubject.objects.filter(
                    branch=class_obj.branch, status=1
                ).select_related('subject')
                if semester:
                    bs_qs = bs_qs.filter(semester=int(semester))
                branch_subjects = [
                    {'id': bs.subject.id, 'subject_name': bs.subject.subject_name, 'subject_code': bs.subject.subject_code}
                    for bs in bs_qs
                ]
            else:
                branch_subjects = []
        except Class.DoesNotExist:
            branch_subjects = []

        seen = set()
        subjects = []
        for s in subjects_from_sc + branch_subjects:
            if s['id'] not in seen:
                seen.add(s['id'])
                subjects.append(s)

        return JsonResponse({'students': students, 'subjects': subjects})
    return JsonResponse({'students': [], 'subjects': []})


@login_required
def manage_result(request):
    results = Result.objects.select_related('student', 'student_class').order_by('student__name')
    q = request.GET.get('q', '').strip()
    if q:
        results = results.filter(
            Q(student__name__icontains=q) | Q(student__roll_id__icontains=q) |
            Q(student_class__class_name__icontains=q) | Q(student_class__section__icontains=q)
        )
    students = {}
    for res in results:
        stu_id = res.student.id
        if stu_id not in students:
            students[stu_id] = {
                'student': res.student,
                'class': res.student_class,
            }
    result_rows = list(students.values())
    page_obj = paginate(request, result_rows)
    return render(request, 'manage_result.html', {'results': page_obj, 'page_obj': page_obj, 'q': q})


@login_required
def edit_result(request, stid):
    student = get_object_or_404(Student, id=stid)
    results = Result.objects.filter(student=student)

    if request.method == 'POST':
        ids = request.POST.getlist('id[]')
        marks_list = request.POST.getlist('marks[]')
        for i in range(len(ids)):
            result_obj = get_object_or_404(Result, id=ids[i])
            result_obj.marks = int(marks_list[i])
            result_obj.save()

        if student.email:
            send_mail(
                subject='Your Result Has Been Updated - SRMS',
                message=(
                    f'Dear {student.name},\n\nYour result has been updated by the school.\n\n'
                    'Please visit the school portal to check your updated result.\n\n'
                    f'Roll ID: {student.roll_id}\nClass: {student.student_class}\n\nRegards,\nSRMS College'
                ),
                from_email=None,
                recipient_list=[student.email],
                fail_silently=True,
            )

        for parent in Parent.objects.filter(student=student).select_related('user'):
            if parent.user.email:
                send_mail(
                    subject=f'Result Updated for {student.name} - SRMS',
                    message=(
                        f'Dear {parent.user.get_full_name()},\n\n'
                        f'The result for your child {student.name} has been updated.\n\n'
                        'Please login to the parent portal to view the updated result.\n\nRegards,\nSRMS College'
                    ),
                    from_email=None,
                    recipient_list=[parent.user.email],
                    fail_silently=True,
                )

        messages.success(request, "Results updated successfully!")
        return redirect('manage_result')
    return render(request, 'edit_result.html', {'student': student, 'results': results})


def search_result(request):
    classes = Class.objects.all()
    return render(request, 'search_result.html', {'classes': classes})


def check_result(request):
    if request.method == 'POST':
        rollid = request.POST.get('rollid')
        class_id = request.POST.get('class')
        semester_id = request.POST.get('semester')
        try:
            student = Student.objects.get(roll_id=rollid, student_class_id=class_id)
            
            # Fetch all results of this student for trend analytics
            all_results = Result.objects.filter(student=student).select_related('subject').order_by('-posting_date')
            
            # Fetch results filtered by semester for the main marksheet display
            results = all_results
            if semester_id:
                results = results.filter(semester=int(semester_id))

            if not results.exists():
                if semester_id:
                    messages.error(request, f"No result found for Semester {semester_id} of the provided Student ID and Class.")
                else:
                    messages.error(request, "No result found for the provided Student ID and Class.")
                return redirect('search_result')

            subject_count = results.count()

            failed_subjects = [r for r in results if not r.is_subject_pass]
            passed_subjects = [r for r in results if r.is_subject_pass]
            is_failed = len(failed_subjects) > 0

            total_obtained = sum(r.total_obtained for r in results)
            total_max      = sum(r.total_max for r in results)
            percentage     = round((total_obtained / total_max * 100) if total_max > 0 else 0, 2)
            grade          = get_grade(percentage, is_failed)
            grade_point    = get_grade_point(grade)
            sgpa           = get_sgpa(results)

            # Class size & Class Rank (based on all_results SGPA of students in the same class)
            class_students = Student.objects.filter(student_class=student.student_class)
            class_size = class_students.count()
            student_rankings = []
            for s in class_students:
                s_results = Result.objects.filter(student=s)
                if semester_id:
                    s_results = s_results.filter(semester=int(semester_id))
                s_sgpa = get_sgpa(s_results) if s_results.exists() else 0.0
                student_rankings.append((s.id, s_sgpa))
            student_rankings.sort(key=lambda x: x[1], reverse=True)
            class_rank = 1
            for idx, (s_id, score) in enumerate(student_rankings):
                if s_id == student.id:
                    class_rank = idx + 1
                    break

            passed_count = len(passed_subjects)
            total_subjects = len(results)

            # Best Subject (from current semester/results)
            best_result = None
            best_pct = -1.0
            for r in results:
                if r.subject_percentage > best_pct:
                    best_pct = r.subject_percentage
                    best_result = r
            best_subject_name = "N/A"
            best_subject_score = 0
            if best_result and best_result.subject:
                best_subject_name = best_result.subject.subject_name
                if "Computer" in best_subject_name:
                    best_subject_name = "Computer"
                elif len(best_subject_name) > 12:
                    best_subject_name = best_subject_name.split()[0]
                best_subject_score = int(best_result.total_obtained)

            # Trend Chart (always use all_results for multi-semester trend)
            def get_result_semester(r):
                if r.semester:
                    return r.semester
                if r.student.student_class and r.student.student_class.branch and r.subject:
                    bs = BranchSubject.objects.filter(
                        branch=r.student.student_class.branch,
                        subject=r.subject
                    ).first()
                    if bs:
                        return bs.semester
                return 1

            semester_results = {}
            for r in all_results:
                sem = get_result_semester(r)
                if sem not in semester_results:
                    semester_results[sem] = []
                semester_results[sem].append(r)
            
            sorted_sems = sorted(semester_results.keys())
            trend_labels = []
            student_trend = []
            class_trend = []
            
            for sem in sorted_sems:
                sem_res = semester_results[sem]
                student_trend.append(get_sgpa(sem_res))
                trend_labels.append(f"Sem {sem}")
                
                # Class average SGPA for this semester
                class_results_sem = Result.objects.filter(
                    student__in=class_students,
                    semester=sem
                )
                if not class_results_sem.exists():
                    all_class_res = Result.objects.filter(student__in=class_students).select_related('student__student_class__branch', 'subject')
                    sem_class_res = [cr for cr in all_class_res if get_result_semester(cr) == sem]
                    class_trend.append(get_sgpa(sem_class_res))
                else:
                    class_trend.append(get_sgpa(class_results_sem))

            import json
            # Radar & Bar Chart (using current results)
            radar_labels = []
            radar_data = []
            bar_labels = []
            bar_data = []
            for r in results:
                if r.subject:
                    name = r.subject.subject_name
                    short = name.split()[0]
                    if "Computer" in name:
                        short = "Computer"
                    radar_labels.append(short)
                    radar_data.append(r.subject_percentage)
                    bar_labels.append(short)
                    bar_data.append(r.subject_percentage)

            # School-wide Top Performers ranking
            all_active_students = Student.objects.filter(status=1)
            school_rankings = []
            for s in all_active_students:
                s_results = Result.objects.filter(student=s)
                if semester_id:
                    s_results = s_results.filter(semester=int(semester_id))
                if s_results.exists():
                    s_sgpa = get_sgpa(s_results)
                    school_rankings.append({
                        'name': s.name,
                        'grade': f"Grade {s.student_class.class_numeric}-{s.student_class.section}" if s.student_class else "Grade 10-A",
                        'avatar': "".join(p[0] for p in s.name.split()[:2]).upper(),
                        'gpa': f"{s_sgpa:.2f}",
                        'raw_sgpa': s_sgpa
                    })
            school_rankings.sort(key=lambda x: x['raw_sgpa'], reverse=True)
            top_performers = school_rankings[:5]

            # Upcoming Exams
            from resultapp.models import Exam
            upcoming_exams_qs = Exam.objects.filter(student_class=student.student_class).select_related('subject').order_by('exam_date')
            upcoming_exams = []
            for idx, ex in enumerate(upcoming_exams_qs):
                upcoming_exams.append({
                    'subject': ex.subject.subject_name,
                    'day': ex.exam_date.strftime("%d"),
                    'day_name': ex.exam_date.strftime("%a"),
                    'month': ex.exam_date.strftime("%b"),
                    'soon': idx == 0
                })

            # Activity Feed
            activities = []
            notices = Notice.objects.all().order_by('-posting_date')[:3]
            for n in notices:
                activities.append({
                    'text': n.title,
                    'time': n.posting_date.strftime("%d %b %Y"),
                    'type': 'warning',
                    'icon': 'fa-bullhorn'
                })
            for r in results[:3]:
                activities.append({
                    'text': f"Result published for {r.subject.subject_name if r.subject else 'Subject'}",
                    'time': r.posting_date.strftime("%d %b %Y") if r.posting_date else "Recent",
                    'type': 'success',
                    'icon': 'fa-check-circle'
                })

            # Detailed results with trend deltas
            detailed_results = []
            for r in results:
                prior = (
                    Result.objects
                    .filter(student=student, subject=r.subject, posting_date__lt=r.posting_date)
                    .order_by('-posting_date')
                    .first()
                )
                if prior is not None:
                    delta = round(r.subject_percentage - prior.subject_percentage, 1)
                else:
                    delta = None

                detailed_results.append({
                    'subject': r.subject.subject_name if r.subject else 'Unknown',
                    'code':    r.subject.subject_code if r.subject else 'SUB-001',
                    'score':   r.total_obtained,
                    'max':     r.total_max,
                    'percentage': r.subject_percentage,
                    'grade':   r.nep_grade,
                    'delta':   delta,
                })

            return render(request, 'result_page.html', {
                'student': student,
                'results': results,
                'total_marks': total_obtained,
                'max_marks': total_max,
                'percentage': percentage,
                'avg_marks': round(total_obtained / len(results) if results else 0, 2),
                'failed_subjects': failed_subjects,
                'passed_subjects': passed_subjects,
                'is_failed': is_failed,
                'grade': grade,
                'sgpa': f"{sgpa:.2f}",
                'class_rank': class_rank,
                'class_size': class_size,
                'passed_count': passed_count,
                'total_subjects': total_subjects,
                'best_subject_name': best_subject_name,
                'best_subject_score': best_subject_score,
                'trend_labels': json.dumps(trend_labels),
                'student_trend': json.dumps(student_trend),
                'class_trend': json.dumps(class_trend),
                'radar_labels': json.dumps(radar_labels),
                'radar_data': json.dumps(radar_data),
                'bar_labels': json.dumps(bar_labels),
                'bar_data': json.dumps(bar_data),
                'top_performers': top_performers,
                'upcoming_exams': upcoming_exams,
                'activities': activities,
                'detailed_results': detailed_results,
                'selected_semester': semester_id,
            })

        except Student.DoesNotExist:
            messages.error(request, "No result found for the provided Student ID and Class.")
            return redirect('search_result')
        except Exception:
            logger.exception("Error checking result for Roll ID %s", rollid)
            messages.error(request, "Couldn't calculate the result right now. Please try again.")
            return redirect('search_result')

    return redirect('search_result')


def get_student_percentage(request):
    student_id = request.GET.get('student_id')
    if not student_id:
        return JsonResponse({'percentage': None, 'grade': 'N/A'})
    try:
        student = Student.objects.get(id=student_id)
        results = Result.objects.filter(student=student)
        if not results.exists():
            return JsonResponse({'percentage': None, 'grade': 'N/A'})
        total_marks = sum(r.total_obtained for r in results)
        max_total   = sum(r.total_max for r in results)
        percentage  = round((total_marks / max_total) * 100 if max_total > 0 else 0, 2)
        failed_subjects = [r for r in results if not r.is_subject_pass]
        is_failed = len(failed_subjects) > 0
        return JsonResponse({'percentage': percentage, 'grade': get_grade(percentage, is_failed)})
    except Student.DoesNotExist:
        return JsonResponse({'percentage': None, 'grade': 'N/A'})
    except Exception:
        logger.exception("Error getting student percentage")
        return JsonResponse({'percentage': None, 'grade': 'N/A', 'error': 'An unexpected error occurred.'})


@login_required
def create_parent_account(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        student_id = request.POST.get('student')
        relationship = request.POST.get('relationship')

        try:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                first_name=first_name,
                last_name=last_name,
            )
            student = get_object_or_404(Student, id=student_id)
            Parent.objects.create(
                user=user,
                phone=phone,
                address=address,
                student=student,
                relationship=relationship,
            )
        except IntegrityError:
            messages.error(request, f'The username "{username}" is already taken. Please choose another.')
            return redirect('create_parent_account')
        except Exception:
            logger.exception("Failed to create parent account")
            messages.error(request, 'Could not create the parent account. An unexpected error occurred.')
            return redirect('create_parent_account')

        try:
            if email:
                login_url = request.build_absolute_uri(reverse('parent_login'))
                send_mail(
                    subject='Your Parent Account Has Been Created - SRMS',
                    message=(
                        f'Dear {first_name} {last_name},\n\n'
                        'Your parent account has been created successfully.\n\n'
                        f'Username: {username}\n'
                        f'Login URL: {login_url}\n\n'
                        'Please use the password set by the administrator to log in. '
                        'You can change it after your first login.\n\n'
                        f'You can now track the following for {student.name}:\n'
                        '- Results & Marks\n- Attendance\n- Progress Reports\n\n'
                        'Regards,\nSRMS College'
                    ),
                    from_email=None,
                    recipient_list=[email],
                    fail_silently=True,
                )

            messages.success(request, f'Parent account created successfully for {student.name}')
            return redirect('manage_parents')
        except Exception as e:
            messages.success(request, f'Parent account created successfully for {student.name}')
            messages.warning(request, f'Note: the welcome email may not have been sent ({str(e)}).')
            return redirect('manage_parents')

    students = Student.objects.filter(status=1)
    return render(request, 'admin/create_parent.html', {'students': students})


@login_required
def manage_parents(request):
    if request.method == 'POST':
        if request.POST.get('delete'):
            try:
                parent_obj = get_object_or_404(Parent, id=request.POST.get('delete'))
                user = parent_obj.user
                parent_obj.delete()
                user.delete()
                messages.success(request, "Parent account deleted successfully!")
            except Exception:
                logger.exception("Failed to delete parent account")
                messages.error(request, "Couldn't delete the parent account. An unexpected error occurred.")
            return redirect('manage_parents')

        elif request.POST.get('parent_id') and request.POST.get('new_password'):
            try:
                parent_id = request.POST.get('parent_id')
                new_password = request.POST.get('new_password')
                if len(new_password) < 6:
                    messages.error(request, "Password must be at least 6 characters long.")
                else:
                    parent_obj = get_object_or_404(Parent, id=parent_id)
                    user = parent_obj.user
                    user.set_password(new_password)
                    user.save()
                    messages.success(request, f"Password for parent '{user.get_full_name() or user.username}' updated successfully!")
            except Exception:
                logger.exception("Failed to update parent password")
                messages.error(request, "Couldn't update parent password. An unexpected error occurred.")
            return redirect('manage_parents')

    parents = Parent.objects.all().select_related('user', 'student')
    return render(request, 'admin/manage_parents.html', {'parents': parents})


@login_required
def add_attendance(request):
    classes  = Class.objects.select_related('branch').all()
    branches = Branch.objects.filter(status=1)

    if request.method == 'POST':
        mode      = request.POST.get('mode', 'single')
        class_id  = request.POST.get('class')
        subject_id = request.POST.get('subject') or None
        semester   = request.POST.get('semester') or None

        try:
            students = Student.objects.filter(student_class_id=class_id, status=1)
            subject_obj = Subject.objects.get(id=subject_id) if subject_id else None

            if mode == 'bulk':
                from_date_str = request.POST.get('from_date')
                to_date_str   = request.POST.get('to_date')
                from datetime import date as date_type
                from_dt = date_type.fromisoformat(from_date_str)
                to_dt   = date_type.fromisoformat(to_date_str)
                if from_dt > to_dt:
                    raise ValueError("Start date must be before end date.")

                total_days = (to_dt - from_dt).days + 1
                if total_days > 200:
                    raise ValueError("Date range too large (max 200 days).")

                from resultapp.models import Holiday
                holiday_dates = set(Holiday.objects.filter(date__range=(from_dt, to_dt)).values_list('date', flat=True))

                dates = [
                    from_dt + timedelta(days=i)
                    for i in range(total_days)
                    if (from_dt + timedelta(days=i)).weekday() != 6
                    and (from_dt + timedelta(days=i)) not in holiday_dates
                ]

                records_saved = 0
                for day in dates:
                    for student in students:
                        status  = request.POST.get(f'status_{student.id}', 'present')
                        remarks = request.POST.get(f'remarks_{student.id}', '')

                        existing_rec = Attendance.objects.filter(
                            student=student,
                            date=day,
                            subject=subject_obj
                        ).first()
                        was_absent = existing_rec and existing_rec.status == 'absent'

                        Attendance.objects.update_or_create(
                            student=student,
                            date=day,
                            subject=subject_obj,
                            defaults={
                                'status': status,
                                'remarks': remarks,
                                'semester': int(semester) if semester else None,
                            },
                        )
                        records_saved += 1

                        if status == 'absent' and not was_absent:
                            for parent in Parent.objects.filter(student=student).select_related('user'):
                                if getattr(parent, 'email_alerts', True) and parent.user.email:
                                    send_mail(
                                        subject=f'Attendance Alert: {student.name} was Absent - SRMS',
                                        message=(
                                            f'Dear {parent.user.get_full_name()},\n\n'
                                            f'Your child {student.name} was marked ABSENT on {day}.\n\n'
                                            f'Subject: {subject_obj.subject_name if subject_obj else "General"}\n'
                                            f'Remarks: {remarks if remarks else "No remarks"}\n\n'
                                            'Please contact the school if you have any questions.\n\nRegards,\nSRMS School'
                                        ),
                                        from_email=None,
                                        recipient_list=[parent.user.email],
                                        fail_silently=True,
                                    )

                messages.success(request, f"Semester bulk attendance saved: {records_saved} entries across {len(dates)} day(s).")

            else:
                date_str = request.POST.get('date')
                from datetime import date as date_type
                day_obj = date_type.fromisoformat(date_str)
                for student in students:
                    status  = request.POST.get(f'status_{student.id}')
                    remarks = request.POST.get(f'remarks_{student.id}', '')

                    existing_rec = Attendance.objects.filter(
                        student=student,
                        date=day_obj,
                        subject=subject_obj
                    ).first()
                    was_absent = existing_rec and existing_rec.status == 'absent'

                    Attendance.objects.update_or_create(
                        student=student,
                        date=day_obj,
                        subject=subject_obj,
                        defaults={
                            'status': status,
                            'remarks': remarks,
                            'semester': int(semester) if semester else None,
                        },
                    )

                    if status == 'absent' and not was_absent:
                        for parent in Parent.objects.filter(student=student).select_related('user'):
                            if getattr(parent, 'email_alerts', True) and parent.user.email:
                                send_mail(
                                    subject=f'Attendance Alert: {student.name} was Absent - SRMS',
                                    message=(
                                        f'Dear {parent.user.get_full_name()},\n\n'
                                        f'Your child {student.name} was marked ABSENT on {date_str}.\n\n'
                                        f'Subject: {subject_obj.subject_name if subject_obj else "General"}\n'
                                        f'Remarks: {remarks if remarks else "No remarks"}\n\n'
                                        'Please contact the school if you have any questions.\n\nRegards,\nSRMS School'
                                    ),
                                    from_email=None,
                                    recipient_list=[parent.user.email],
                                    fail_silently=True,
                                )

                messages.success(request, "Attendance recorded successfully!")

            return redirect('add_attendance')

        except ValueError as e:
            messages.error(request, f"Invalid input: {str(e)}")
        except Exception:
            logger.exception("Failed to record attendance")
            messages.error(request, "Couldn't record attendance. An unexpected error occurred.")

    return render(request, 'admin/add_attendance.html', {
        'classes': classes,
        'branches': branches,
    })


@login_required
def add_progress_report(request):
    students = Student.objects.filter(status=1)
    if request.method == 'POST':
        try:
            student_id = request.POST.get('student')
            term = request.POST.get('term')
            overall_percentage = request.POST.get('overall_percentage')
            grade = request.POST.get('grade')
            teacher_remarks = request.POST.get('teacher_remarks')
            strengths = request.POST.get('strengths')
            areas_of_improvement = request.POST.get('areas_of_improvement')

            ProgressReport.objects.create(
                student_id=student_id,
                term=term,
                overall_percentage=overall_percentage,
                grade=grade,
                teacher_remarks=teacher_remarks,
                strengths=strengths,
                areas_of_improvement=areas_of_improvement,
            )

            student = get_object_or_404(Student, id=student_id)
        except ValueError:
            messages.error(request, "Overall percentage must be a valid number.")
            return redirect('add_progress_report')
        except Exception:
            logger.exception("Failed to save progress report")
            messages.error(request, "Couldn't save the progress report. An unexpected error occurred.")
            return redirect('add_progress_report')

        try:
            for parent in Parent.objects.filter(student=student).select_related('user'):
                if parent.user.email:
                    send_mail(
                        subject=f'Progress Report Added - {term} - SRMS',
                        message=(
                            f'Dear {parent.user.get_full_name()},\n\n'
                            f'A new progress report has been added for {student.name}.\n\n'
                            f'Term: {term}\nGrade: {grade}\nOverall Percentage: {overall_percentage}%\n'
                            f'Teacher Remarks: {teacher_remarks}\n'
                            f'Strengths: {strengths or "N/A"}\n'
                            f'Areas of Improvement: {areas_of_improvement or "N/A"}\n\n'
                            'Please login to the parent portal for more details.\n\nRegards,\nSRMS College'
                        ),
                        from_email=None,
                        recipient_list=[parent.user.email],
                        fail_silently=True,
                    )

            messages.success(request, "Progress report added successfully!")
            return redirect('add_progress_report')
        except Exception as e:
            messages.success(request, "Progress report added successfully!")
            messages.warning(request, f"Note: the parent notification email may not have been sent ({str(e)}).")
            return redirect('add_progress_report')

    return render(request, 'admin/add_progress_report.html', {'students': students})
